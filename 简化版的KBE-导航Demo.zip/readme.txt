这个基于本群的 简化版的KBE-Demo.zip 改写而来。
其中重点谈到了导航的使用。

kbengine_server_nav_demo:提供 %KBE_ROOT%/scripts,其他关于KBE部署查看官网
kbengine_unity3d_nav_demo:客户端