﻿该 demo 为了让初学者 能够更好理解 KBEngine 而提供，大大简化了官方demo。
当然其中很多API都没有涉及到。

kbengine_server_demo-mini:提供 %KBE_ROOT%/scripts,其他关于KBE部署查看官网
kbengine_unity3d_demo-mini:客户端